# PixelForge 1.5 — Web editor

Editor estático de pixel art por capas y fotogramas. Una sola página sin dependencias externas.

## Desplegar a Vercel + GitHub
1. Crea un repositorio nuevo (preferiblemente privado) llamado `pixelforge` en GitHub.
2. Sube `index.html` a la raíz del repositorio.
3. En Vercel, selecciona **Add New > Project** e importa el repositorio.
4. Framework Preset: **Other**. No requiere comandos de instalación ni de compilación.
5. Despliega. Vercel proporcionará una URL `*.vercel.app` y actualizará la publicación tras cambios en la rama conectada.

## Advertencia sobre datos
El editor 1.5 guarda los proyectos en `localStorage` del navegador actual. No existe todavía sincronización de proyectos entre dispositivos, copias de seguridad en la nube ni edición colaborativa. Subir una nueva versión del HTML no migra los datos guardados de un navegador a otro.

Para colaboración en vivo, una próxima fase debería incorporar autenticación, una base de datos (p. ej., Firestore) y sincronización con control de conflictos.
